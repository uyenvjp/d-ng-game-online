Secret HMAC va config.json duoc tao tren VPS luc cai. Khong chia se hoac commit.
