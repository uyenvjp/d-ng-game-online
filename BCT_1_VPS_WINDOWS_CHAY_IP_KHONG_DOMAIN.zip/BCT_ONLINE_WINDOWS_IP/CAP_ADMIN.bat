@echo off
cd /d "%~dp0"
echo Run as Administrator.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CAP_QUYEN_ADMIN.ps1"
pause
