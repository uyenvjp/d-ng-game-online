﻿#Requires -RunAsAdministrator
param(
 [string]$Domain = '',
 [string]$InstallDir = 'C:\BCTOnline'
)
$ErrorActionPreference='Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$src=Split-Path -Parent $MyInvocation.MyCommand.Path
if(!$Domain){$Domain=(Read-Host 'Nhap ten mien da tro DNS (vi du: game.example.com)').Trim()}
$Domain=$Domain.Trim().ToLowerInvariant().TrimEnd('.')
if($Domain -notmatch '^(?=.{4,253}$)(?!-)[a-z0-9-]+(\.[a-z0-9-]+)+$' -or $Domain -match '(^|\.)-|-($|\.)') { throw 'Ten mien khong hop le. Phai co domain va DNS A record.' }
$nodeCmd=Get-Command node.exe -ErrorAction SilentlyContinue
if(!$nodeCmd){throw 'Chua cai Node.js LTS 22.16+ (khuyen nghi 26 LTS). Tai tai https://nodejs.org/en/download/ roi chay lai.'}
$nodeExe=$nodeCmd.Source
$nodeMajor=[int]((& $nodeExe -p 'process.versions.node').Split('.')[0]);if($nodeMajor -lt 22){throw 'Node.js qua cu. Cai Node.js 26 LTS.'}
if(([System.Environment]::OSVersion.Version.Major) -lt 10){Write-Warning 'Khuyen dung Windows Server 2022 hoac 2025'}
$dest=[System.IO.Path]::GetFullPath($InstallDir)
foreach($dir in @($dest, "$dest\game", "$dest\spldb", "$dest\config", "$dest\bin", "$dest\data", "$dest\backups", "$dest\logs", "$dest\scripts", "$dest\caddy-data")){New-Item -ItemType Directory -Force $dir|Out-Null}
# Stop tasks if updating. Never delete existing data or secret.
foreach($name in @('BCT_SPLDB','BCT_CADDY')){
 if(Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue){Stop-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue;Start-Sleep -Seconds 2}
}
Copy-Item "$src\game\index.html" "$dest\game\index.html" -Force
Copy-Item "$src\spldb\*.mjs" "$dest\spldb\" -Force
Copy-Item "$src\scripts\RUN_*.ps1" "$dest\scripts\" -Force
foreach($f in @('CAP_QUYEN_ADMIN.ps1','SAO_LUU_DATABASE.ps1','KIEM_TRA_SERVER.ps1','CAP_ADMIN.bat','SAO_LUU.bat','KIEM_TRA.bat','HUONG_DAN_1_VPS_WINDOWS.md')){
  if((Join-Path $src $f) -ne (Join-Path $dest $f)){Copy-Item (Join-Path $src $f) (Join-Path $dest $f) -Force}
}
Copy-Item "$src\config\Caddyfile.template" "$dest\config\Caddyfile.template" -Force
# One-time 256-bit HMAC secret generated on the VPS; no shared static secret.
$secretFile=Join-Path $dest 'config\spldb-hmac-secret.txt'
if(!(Test-Path $secretFile)){
 $rng=[System.Security.Cryptography.RandomNumberGenerator]::Create();$raw=New-Object byte[] 32;$rng.GetBytes($raw);$rng.Dispose()
 ([BitConverter]::ToString($raw)).Replace('-','').ToLowerInvariant() | Set-Content -Path $secretFile -Encoding Ascii -NoNewline
}
# Locate or download official Caddy Windows x64 from Github releases.
$caddy=Join-Path $dest 'bin\caddy.exe'
if(!(Test-Path $caddy)){
 Write-Host 'Dang lay Caddy Windows x64 tu github.com/caddyserver/caddy ...'
 try {
  $rel=Invoke-RestMethod 'https://api.github.com/repos/caddyserver/caddy/releases/latest' -Headers @{'User-Agent'='BCT-Windows-Installer'}
  $asset=$rel.assets|Where-Object {$_.name -match 'windows_amd64\.zip$'}|Select-Object -First 1
  if(!$asset){throw 'Khong tim thay goi windows_amd64.zip'}
  $zip=Join-Path $env:TEMP 'bct-caddy.zip';$tmp=Join-Path $env:TEMP 'bct-caddy-extract'
  if(Test-Path $tmp){Remove-Item -Recurse -Force $tmp}
  Invoke-WebRequest -UseBasicParsing $asset.browser_download_url -OutFile $zip
  Expand-Archive $zip -DestinationPath $tmp -Force
  $exe=Get-ChildItem $tmp -Recurse -Filter 'caddy.exe'|Select-Object -First 1
  if(!$exe){throw 'Goi tai xuong khong co caddy.exe'}
  Copy-Item $exe.FullName $caddy -Force
 } catch { throw "Khong tu tai duoc Caddy: $_ . Tai file tu https://caddyserver.com/download (Windows amd64) roi dat caddy.exe vao $dest\bin\ va chay lai." }
}
$cfg=@{Domain=$Domain;NodeExe=$nodeExe;InstallDir=$dest;InstalledAt=(Get-Date).ToString('o')}
$cfg|ConvertTo-Json|Set-Content (Join-Path $dest 'config\install.json') -Encoding UTF8
$gameDir=(Join-Path $dest 'game').Replace('\','/')
$dataDir=(Join-Path $dest 'caddy-data').Replace('\','/')
$text=Get-Content (Join-Path $dest 'config\Caddyfile.template') -Raw
$text=$text.Replace('__DOMAIN__',$Domain).Replace('__GAME_ROOT__',$gameDir).Replace('__CADDY_STORAGE__',$dataDir)
[System.IO.File]::WriteAllText((Join-Path $dest 'config\Caddyfile'),$text,(New-Object System.Text.UTF8Encoding($false)))
# ACL: LOCALSERVICE can write only runtime data, secrets, logs and TLS storage.
foreach($dir in @('data','backups','logs','caddy-data')){
 $path=Join-Path $dest $dir
 & icacls.exe $path /grant '*S-1-5-19:(OI)(CI)M' /T | Out-Null
 if($LASTEXITCODE -ne 0){throw "Khong cap duoc quyen LOCAL SERVICE cho $path"}
}
& icacls.exe $secretFile /inheritance:r /grant '*S-1-5-19:R' '*S-1-5-32-544:F' '*S-1-5-18:F' |Out-Null
if($LASTEXITCODE -ne 0){throw 'Khong dat duoc quyen secret'}
& $caddy validate --config (Join-Path $dest 'config\Caddyfile') --adapter caddyfile
if($LASTEXITCODE -ne 0){throw 'Caddyfile khong hop le'}
$principal=New-ScheduledTaskPrincipal -UserId 'LOCALSERVICE' -LogonType ServiceAccount
$settings=New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1) -StartWhenAvailable -MultipleInstances IgnoreNew
$trigger=New-ScheduledTaskTrigger -AtStartup
foreach($task in @(@('BCT_SPLDB','RUN_SPLDB.ps1'),@('BCT_CADDY','RUN_CADDY.ps1'))){
 $name=$task[0];$ps1=Join-Path $dest ('scripts\'+$task[1]);
 if(Get-ScheduledTask -TaskName $name -ErrorAction SilentlyContinue){Unregister-ScheduledTask -TaskName $name -Confirm:$false}
 $act=New-ScheduledTaskAction -Execute 'powershell.exe' -Argument ('-NoProfile -NonInteractive -ExecutionPolicy Bypass -File "'+$ps1+'"') -WorkingDirectory $dest
 Register-ScheduledTask -TaskName $name -Action $act -Trigger $trigger -Principal $principal -Settings $settings -Description ('BCT Online '+$name)|Out-Null
}
foreach($port in @(80,443)){
 $name="BCT HTTPS $port"
 if(!(Get-NetFirewallRule -DisplayName $name -ErrorAction SilentlyContinue)){
  New-NetFirewallRule -DisplayName $name -Direction Inbound -Action Allow -Protocol TCP -LocalPort $port -Profile Any | Out-Null
 }
}
# 8787 listens on 127.0.0.1 only; never add an inbound rule for it.
Start-ScheduledTask -TaskName BCT_SPLDB
Start-Sleep -Seconds 3
Start-ScheduledTask -TaskName BCT_CADDY
Write-Host ''
Write-Host 'DA CAI DAT XONG - 1 VPS WINDOWS' -ForegroundColor Green
Write-Host "Game: https://$Domain"
Write-Host "SPLDB: https://$Domain/api/v1/ (127.0.0.1:8787 noi bo)"
Write-Host "Du lieu: $dest\data\accounts.sqlite"
Write-Host 'Can DNS A tro dung IP VPS, port 80/443 duoc mo va khong bi IIS chiem.'
Write-Host 'Kiem tra: Get-ScheduledTask BCT_*; Invoke-RestMethod https://TEN-MIEN/health'
Write-Host 'Neu Caddy chua cap HTTPS, xem logs va DNS; khong mo port 8787 ra Internet.'
