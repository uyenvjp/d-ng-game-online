# BÍ CẢNH TẦM BẢO — ONLINE 1 VPS WINDOWS (KHÔNG DOCKER)

## Mô hình

Một **VPS Windows Server 2022 hoặc 2025**, một IP công khai và một domain (ví dụ `game.example.com`).
- Caddy trên cùng VPS phát `game/index.html` tại `https://game.example.com`.
- Caddy chuyển các đường dẫn `/api/v1/*` và `/health` vào **SPLDB** chạy trên loopback `127.0.0.1:8787`.
- SPLDB giữ account/SQLite trong `C:\BCTOnline\data\accounts.sqlite`, KHÔNG nằm trong thư mục web game.
- Cả Caddy và SPLDB được đăng ký Windows Scheduled Tasks chạy lúc máy khởi động bằng quyền hạn chế `LOCALSERVICE` (không dùng SYSTEM).

## Điều kiện trước khi cài

1. Chuẩn bị VPS Windows Server, khuyến nghị tối thiểu **2 vCPU, 4 GB RAM, SSD 40 GB** để thử nghiệm nhỏ (không bảo đảm hiệu năng cho mọi số người chơi).
2. Có **domain thực**; tạo DNS **A record** `game.example.com` trỏ IP công khai VPS.
3. Mở inbound **TCP 80 và TCP 443** trên cả Windows Firewall và firewall panel nhà cung cấp. **KHÔNG mở 8787**; không mở RDP 3389 cho toàn Internet nếu có thể hạn chế IP/VPN.
4. Cài **Node.js LTS >=22.16**, khuyến nghị Node 26 LTS từ https://nodejs.org/en/download/ (Node 26.13.0 là LTS từ 28/10/2026).
5. Đảm bảo **IIS, Apache, Nginx** hoặc phần mềm khác không chiếm 80/443; nhớ sao lưu DB cũ trước khi cập nhật.
6. Windows được cập nhật bảo mật, đồng bộ đồng hồ, và có quyền quản trị để cài task.

## Cài trong vài bước bằng RDP

1. Giải nén ZIP vào thư mục trên VPS, ví dụ `C:\Users\Administrator\Downloads\BCT_ONLINE_WINDOWS_1_VPS`.
2. **Bấm chuột phải** `CHAY_CAI_DAT.bat` → **Run as administrator**.
3. Nhập domain (ví dụ `game.example.com`) khi được hỏi. Script tự cài vào `C:\BCTOnline`, **không xóa database cũ** khi chạy lại.
4. Nếu không tự tải được Caddy do Github bị chặn, tải bản **Windows amd64** từ https://caddyserver.com/download, đặt `caddy.exe` tại `C:\BCTOnline\bin\caddy.exe`, rồi chạy lại installer.
5. Khi DNS đã trỏ đúng, mở `https://game.example.com`; Caddy tự lấy HTTPS (cần cổng 80/443 từ Internet tới VPS).
6. Người chơi vào **☰ → Tài khoản & cài đặt → Đăng nhập / Quản lý tài khoản**, đăng ký/login. URL SPLDB luôn cùng domain với game, không dùng `account.*` nữa.

## Kiểm tra

Mở PowerShell trên VPS:
```powershell
Get-ScheduledTask -TaskName BCT_SPLDB,BCT_CADDY | Select TaskName,State
Invoke-RestMethod http://127.0.0.1:8787/health
Invoke-RestMethod https://game.example.com/health
```
Hoặc chạy `KIEM_TRA.bat`. Nhật ký: `C:\BCTOnline\logs\spldb.log` và `caddy.log`.

## Cấp quyền Admin

- Đăng ký username trong game trước.
- Bấm phải `CAP_ADMIN.bat` → Run as administrator, nhập username; mặc định cấp `admin`.
- Hoặc chạy `powershell -NoProfile -ExecutionPolicy Bypass -File .\CAP_QUYEN_ADMIN.ps1 -Username laphong -Role admin`.
- Lệnh dừng SPLDB trước khi cập nhật vai trò, thu hồi session, sau đó chạy lại. Đăng xuất/đăng nhập lại.
- Thu hồi: thay `-Role member`. Không tự động cấp quyền theo tên tài khoản.

## Backup và cập nhật

- `SAO_LUU.bat` gọi công cụ backup SQLite nhất quán qua API Node.js, không phải copy `.sqlite` đang ghi một cách tùy tiện.
- Lưu bản backup ngoài VPS, mã hóa, kiểm tra khôi phục định kỳ.
- Cập nhật **chỉ game**: thay `C:\BCTOnline\game\index.html` (không cần tắt SPLDB).
- Cập nhật backend: sao lưu trước, dừng task SPLDB, thay `spldb\server.mjs`, kiểm tra migration rồi bật task lại.
- Dữ liệu database và HMAC secret được giữ nguyên khi cài lại; đừng chia sẻ `config/spldb-hmac-secret.txt`.

## Nếu không truy cập được

- DNS có đúng IP VPS không? Provider firewall cho TCP 80/443 chưa?
- `Get-NetTCPConnection -LocalPort 80,443,8787 -State Listen` — nếu IIS chiếm 80/443, dừng IIS hoặc sửa cấu hình xung đột.
- Kiểm tra trạng thái task và log. HTTPS có thể chưa được cấp khi DNS chưa trỏ đúng.
- Test proxy `https://game.example.com/health` trên một máy khác; chỉ `localhost:8787/health` được phép truy cập trực tiếp trên VPS.
- Máy chủ có thể cần được truy cập từ bên ngoài để lấy chứng chỉ, không nên dùng IP thay domain nếu muốn HTTPS công khai.

## Giới hạn bảo mật/gameplay

- Cùng VPS nghĩa là **tách tiến trình và thư mục**, không phải phân tách máy chủ vật lý. Nếu VPS bị chiếm quyền quản trị, cả game và database đều có nguy cơ.
- Hiện SPLDB chỉ đảm nhận đăng nhập, save online, phiên và kiểm tra tốc độ cơ bản. Client vẫn quyết định nhiều kết quả chiến đấu/vật phẩm. Save của client được đánh dấu **unverified**. Không quảng cáo chống hack tuyệt đối hoặc multiplayer thời gian thực.
- Không lưu tài khoản/mật khẩu trong HTML; SPLDB có cookie HttpOnly và SQLite trong thư mục riêng.
- Các task đang dùng `LOCALSERVICE`, không phải tài khoản SYSTEM. Giới hạn quyền truy cập RDP, bật Windows Updates và backup dữ liệu.
- **Không** có dữ liệu tài khoản thật, tên miền hay chứng chỉ trong ZIP. Đây là bộ triển khai, **chưa phải server đang online**.
