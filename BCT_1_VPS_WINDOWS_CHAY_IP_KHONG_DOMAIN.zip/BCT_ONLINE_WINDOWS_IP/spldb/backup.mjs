/** SQLite consistent backup while SPLDB is running. */
import { DatabaseSync, backup } from 'node:sqlite';
import { existsSync, mkdirSync } from 'node:fs';
import { resolve, dirname } from 'node:path';
const file=resolve(process.env.SPLDB_DB_PATH||'./data/accounts.sqlite');
if(!existsSync(file)){console.error('Khong tim thay database:',file);process.exit(1)}
const dest=resolve(process.argv[2]||'./backups');mkdirSync(dest,{recursive:true});
const stamp=new Date().toISOString().replace(/[.:]/g,'-');
const target=resolve(dest,`spldb-${stamp}.sqlite`);
const db=new DatabaseSync(file,{readOnly:true});
try{await backup(db,target,{rate:50});console.log('BACKUP_OK',target)}
finally{db.close()}
