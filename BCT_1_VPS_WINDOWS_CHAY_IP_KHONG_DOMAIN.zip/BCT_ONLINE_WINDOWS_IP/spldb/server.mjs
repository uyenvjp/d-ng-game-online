/** SPLDB 1.0 — dedicated account/save service for Bí Cảnh Tầm Bảo.
 * Node.js >=22.16 (built-in SQLite). Deploy separately from game static host.
 * No gameplay authority: imported/client-generated inventory remains UNVERIFIED.
 */
import http from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { randomBytes, scryptSync, timingSafeEqual, createHash, createHmac } from 'node:crypto';
import { mkdirSync, readFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';

const host=process.env.SPLDB_HOST||'127.0.0.1';
const port=Number(process.env.SPLDB_PORT||8787);
const allowedOrigin=(process.env.SPLDB_ORIGIN||'http://localhost:8000').replace(/\/$/,'');
const secureCookie=process.env.SPLDB_COOKIE_SECURE==='1';
const dbPath=resolve(process.env.SPLDB_DB_PATH||'./private/accounts.sqlite');
const maxSave=Number(process.env.SPLDB_SAVE_MAX_BYTES||524288);
mkdirSync(dirname(dbPath),{recursive:true,mode:0o700});
const db=new DatabaseSync(dbPath);
db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
 CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, username TEXT NOT NULL UNIQUE COLLATE NOCASE, pass_hash TEXT NOT NULL, created INTEGER NOT NULL, role TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('member','admin')));
 CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,expires INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS saves(user_id INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,revision INTEGER NOT NULL,payload TEXT NOT NULL,checksum TEXT NOT NULL,updated INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS backups(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,revision INTEGER NOT NULL,payload TEXT NOT NULL,updated INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS raids(id TEXT PRIMARY KEY,user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,started INTEGER NOT NULL,ended INTEGER,reported_ms INTEGER,anomaly INTEGER NOT NULL DEFAULT 0);
 CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,kind TEXT NOT NULL,detail TEXT NOT NULL,at INTEGER NOT NULL);
 CREATE INDEX IF NOT EXISTS idx_backup_user ON backups(user_id,id DESC);
 CREATE INDEX IF NOT EXISTS idx_raid_user ON raids(user_id,started DESC);
 CREATE INDEX IF NOT EXISTS idx_sessions_expires ON sessions(expires);`);
// Migration for databases created before role-based accounts existed.
if(!db.prepare('PRAGMA table_info(users)').all().some(c=>c.name==='role')){
 db.exec("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'member' CHECK(role IN ('member','admin'))");
}

const queries={
 user:db.prepare('SELECT * FROM users WHERE username=?'),
 userId:db.prepare('SELECT id,username,role FROM users WHERE id=?'),
 session:db.prepare('SELECT u.id,u.username,u.role,s.expires FROM sessions s JOIN users u ON u.id=s.user_id WHERE token_hash=?'),
 save:db.prepare('SELECT * FROM saves WHERE user_id=?'),
 sessionInsert:db.prepare('INSERT INTO sessions(token_hash,user_id,expires) VALUES (?,?,?)'),
};
const attempts=new Map();
const now=()=>Date.now();
const sha=v=>createHash('sha256').update(v).digest('hex');
const hmacKey=(process.env.SPLDB_HMAC_KEY_FILE?readFileSync(process.env.SPLDB_HMAC_KEY_FILE,'utf8').trim():process.env.SPLDB_HMAC_KEY)||'';
if(process.env.NODE_ENV==='production' && hmacKey.length<32)throw Error('SPLDB HMAC secret missing or too short (min 32 chars)');
const sign=v=>createHmac('sha256',hmacKey||'local-demo-only-hmac-key-change-in-production').update(v).digest('hex');
const hashPass=p=>{const salt=randomBytes(24).toString('hex');return `scrypt$${salt}$${scryptSync(p,salt,64).toString('hex')}`;};
const checkPass=(p,hash)=>{try{const [alg,salt,hex]=hash.split('$');if(alg!=='scrypt')return false;const expected=Buffer.from(hex,'hex');return expected.length===64&&timingSafeEqual(scryptSync(p,salt,64),expected)}catch{return false}};
const scrub=(x,depth=0)=>{if(depth>12)throw Error('Dữ liệu lồng quá sâu');if(x===null||typeof x==='string'||typeof x==='boolean')return;
 if(typeof x==='number'){if(!Number.isFinite(x)||Math.abs(x)>1e14)throw Error('Chỉ số không hợp lệ');return}
 if(Array.isArray(x)){if(x.length>20000)throw Error('Danh sách quá lớn');for(const y of x)scrub(y,depth+1);return}
 if(typeof x==='object'){const keys=Object.keys(x);if(keys.length>10000)throw Error('Dữ liệu quá nhiều trường');for(const k of keys){if(['__proto__','constructor','prototype'].includes(k))throw Error('Trường bị cấm');scrub(x[k],depth+1)}return}
 throw Error('Kiểu dữ liệu không hợp lệ');};
const audit=(uid,kind,detail)=>db.prepare('INSERT INTO audit(user_id,kind,detail,at) VALUES(?,?,?,?)').run(uid,kind,String(detail).slice(0,450),now());
function json(res,code,obj){const data=JSON.stringify(obj);res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'});res.end(data)}
function setCors(req,res){const origin=req.headers.origin;if(origin===allowedOrigin){res.setHeader('Access-Control-Allow-Origin',allowedOrigin);res.setHeader('Vary','Origin');res.setHeader('Access-Control-Allow-Credentials','true');res.setHeader('Access-Control-Allow-Headers','Content-Type, X-SPLDB-Request');res.setHeader('Access-Control-Allow-Methods','GET,POST,PUT,OPTIONS');return true}return false}
function security(req){
 // Browser same-origin GET frequently omits Origin. Sec-Fetch-Site is a useful
 // browser provenance check, not proof of an authenticated or honest client.
 // CSRF protection for state-changing requests still REQUIRES the exact Origin.
 if(req.headers['x-spldb-request']!=='bct1')return false;
 const origin=req.headers.origin;
 if(origin!==undefined)return origin===allowedOrigin;
 if(req.method!=='GET')return false;
 return req.headers['sec-fetch-site']==='same-origin';
}
function limited(ip,key,max,windowMs){const k=ip+':'+key,t=now();const a=attempts.get(k)||[];const live=a.filter(x=>x>t-windowMs);live.push(t);attempts.set(k,live);return live.length>max}
function rawCookie(req,name){const c=req.headers.cookie||'';return c.split(';').map(v=>v.trim()).find(v=>v.startsWith(name+'='))?.slice(name.length+1)||''}
function auth(req){const tok=rawCookie(req,'spl_session');if(!/^[a-f0-9]{64}$/.test(tok))return null;const a=queries.session.get(sha(tok));if(!a||a.expires<=now())return null;return a}
function cookie(res,value,seconds){const flags=`spl_session=${value}; Path=/api/v1; HttpOnly; SameSite=Lax; Max-Age=${seconds}${secureCookie?'; Secure':''}`;res.setHeader('Set-Cookie',flags)}
function newSession(res,u){const t=randomBytes(32).toString('hex');queries.sessionInsert.run(sha(t),u.id,now()+7*86400e3);cookie(res,t,7*86400)}
async function body(req,limit=1048576){return new Promise((ok,fail)=>{let b='';let size=0;req.on('data',c=>{size+=c.length;if(size>limit){fail(Error('Payload quá lớn'));req.destroy();return}b+=c});req.on('end',()=>{try{ok(JSON.parse(b||'{}'))}catch{fail(Error('JSON không hợp lệ'))}});req.on('error',fail)})}
const saveResponse=uid=>{const r=queries.save.get(uid);return r?{revision:r.revision,save:JSON.parse(r.payload),updated:r.updated,verified:false}:{revision:0,save:null,verified:false}};
function saveValidate(value){if(!value||typeof value!=='object'||Array.isArray(value))throw Error('Save phải là object');scrub(value);const money=value.money,realm=value.realm;if(typeof money!=='number'||!Number.isSafeInteger(money)||money<0||money>2e12)throw Error('Linh thạch không hợp lệ');if(realm!==undefined&&(!Number.isInteger(realm)||realm<0||realm>80))throw Error('Cảnh giới không hợp lệ');for(const k of ['raids','ext','deaths'])if(value[k]!==undefined&&(!Number.isSafeInteger(value[k])||value[k]<0||value[k]>1e9))throw Error('Thống kê trận không hợp lệ');const txt=JSON.stringify(value);if(Buffer.byteLength(txt)>maxSave)throw Error('Save vượt giới hạn lưu');return txt}
function writeSave(uid,expected,value){const txt=saveValidate(value),current=queries.save.get(uid),rev=current?.revision||0;if(rev!==expected)return {conflict:true,actual:rev};
 if(current){ // rudimentary progression-time guard; the game must migrate gameplay to server for real cheat protection
  const old=JSON.parse(current.payload),dt=Math.max(0,now()-current.updated);
  const raidInc=(value.raids||0)-(old.raids||0);const maxInc=Math.max(1,Math.floor(dt/15000)+1);
  if(raidInc>maxInc){audit(uid,'save_rate_reject',`raids +${raidInc}, server elapsed ${dt}ms`);return {invalid:'Tiến độ số lượt tăng nhanh bất thường'}}
 }
 db.exec('BEGIN IMMEDIATE');try{
  if(current){db.prepare('INSERT INTO backups(user_id,revision,payload,updated) VALUES(?,?,?,?)').run(uid,current.revision,current.payload,current.updated);
   db.prepare('DELETE FROM backups WHERE user_id=? AND id NOT IN (SELECT id FROM backups WHERE user_id=? ORDER BY id DESC LIMIT 20)').run(uid,uid);
   db.prepare('UPDATE saves SET revision=?,payload=?,checksum=?,updated=? WHERE user_id=?').run(rev+1,txt,sign(txt),now(),uid);
  }else db.prepare('INSERT INTO saves(user_id,revision,payload,checksum,updated) VALUES(?,?,?,?,?)').run(uid,1,txt,sign(txt),now());
  db.exec('COMMIT');
 }catch(e){db.exec('ROLLBACK');throw e}
 return {revision:rev+1,verified:false,updated:now()};
}
const server=http.createServer(async(req,res)=>{
 try{
  const url=new URL(req.url||'/',`http://${host}`),path=url.pathname;
  const corsOK=setCors(req,res);
  if(req.method==='OPTIONS'){res.writeHead(corsOK?204:403);res.end();return}
  if(path==='/health'){json(res,200,{ok:true,service:'spldb',role:'account-only',privateStorage:true});return}
  if(!path.startsWith('/api/v1/')){json(res,404,{error:'Not found'});return}
  if(!security(req)){json(res,403,{error:'Origin không được phép, hãy mở game từ địa chỉ web đã cấu hình'});return}
  const ip=(String(req.headers['x-spldb-client-ip']||req.socket.remoteAddress||'local')).slice(0,80); // X-SPLDB-Client-IP overwritten by the trusted private Caddy proxy
  if(limited(ip,'api',180,60000)){json(res,429,{error:'Quá nhiều yêu cầu'});return}
  if(path==='/api/v1/register'&&req.method==='POST'){
   if(limited(ip,'register',5,3600e3)){json(res,429,{error:'Đăng ký quá nhiều lần'});return}
   const b=await body(req,2048),u=String(b.username||'').toLowerCase().trim(),p=String(b.password||'');
   if(!/^[a-z0-9_]{3,24}$/.test(u)||p.length<10||p.length>128){json(res,400,{error:'Tên 3–24 ký tự a-z, 0-9, _; mật khẩu 10–128 ký tự'});return}
   if(queries.user.get(u)){json(res,409,{error:'Tên tài khoản đã tồn tại'});return}
   const row=db.prepare("INSERT INTO users(username,pass_hash,created,role) VALUES(?,?,?,'member')").run(u,hashPass(p),now());const user={id:Number(row.lastInsertRowid),username:u,role:'member'};newSession(res,user);audit(user.id,'register','new account');json(res,201,{user:{username:u,role:'member'},...saveResponse(user.id)});return;
  }
  if(path==='/api/v1/login'&&req.method==='POST'){
   if(limited(ip,'login',12,15*60000)){json(res,429,{error:'Đăng nhập quá nhiều lần, thử lại sau'});return}
   const b=await body(req,2048),u=String(b.username||'').toLowerCase().trim(),p=String(b.password||''),a=queries.user.get(u);
   // Equalize timing when username doesn't exist
   if(!checkPass(p,a?.pass_hash||`scrypt$${'0'.repeat(48)}$${'0'.repeat(128)}`)){json(res,401,{error:'Sai tên tài khoản hoặc mật khẩu'});return}
   newSession(res,a);audit(a.id,'login','ok');json(res,200,{user:{username:a.username,role:a.role},...saveResponse(a.id)});return;
  }
  const user=auth(req);if(!user){json(res,401,{error:'Chưa đăng nhập hoặc phiên đã hết hạn'});return}
  if(path==='/api/v1/logout'&&req.method==='POST'){const t=rawCookie(req,'spl_session');db.prepare('DELETE FROM sessions WHERE token_hash=?').run(sha(t));cookie(res,'',0);json(res,200,{ok:true});return}
  if(path==='/api/v1/me'&&req.method==='GET'){json(res,200,{user:{username:user.username,role:user.role},...saveResponse(user.id)});return}
  // The server checks the real account role on EVERY privileged request.
  if(path==='/api/v1/admin/check'&&req.method==='GET'){
    if(user.role!=='admin'){audit(user.id,'admin_denied','role not admin');json(res,403,{error:'Tài khoản không có quyền ADMIN'});return}
    json(res,200,{ok:true,role:'admin'});return;
  }
  if(path==='/api/v1/save'&&req.method==='GET'){json(res,200,saveResponse(user.id));return}
  if(path==='/api/v1/save'&&req.method==='PUT'){
    if(limited(ip,`save:${user.id}`,35,60000)){json(res,429,{error:'Lưu quá nhanh'});return}
    const b=await body(req,maxSave+2048);if(!Number.isSafeInteger(b.revision)||b.revision<0){json(res,400,{error:'Phiên bản save sai'});return}
    let result;try{result=writeSave(user.id,b.revision,b.save)}catch(e){json(res,400,{error:e.message});return}
    if(result.conflict){json(res,409,{error:'Xung đột phiên bản: bản trên server đã mới hơn',revision:result.actual});return}
    if(result.invalid){json(res,409,{error:result.invalid});return}
    json(res,200,result);return;
  }
  if(path==='/api/v1/backups'&&req.method==='GET'){
    const rows=db.prepare('SELECT id,revision,updated FROM backups WHERE user_id=? ORDER BY id DESC LIMIT 20').all(user.id);
    json(res,200,{items:rows});return;
  }
  if(path==='/api/v1/raid/start'&&req.method==='POST'){
    if(limited(ip,`raids:${user.id}`,8,60000)){json(res,429,{error:'Tạo trận quá nhanh'});return}
    const id=randomBytes(20).toString('hex');db.prepare('INSERT INTO raids(id,user_id,started) VALUES(?,?,?)').run(id,user.id,now());json(res,200,{raidId:id,serverStarted:now()});return;
  }
  if(path==='/api/v1/raid/end'&&req.method==='POST'){
    const b=await body(req,2048),id=String(b.raidId||''),clientMs=Number(b.elapsedMs);
    if(!/^[a-f0-9]{40}$/.test(id)||!Number.isFinite(clientMs)||clientMs<0||clientMs>3600000){json(res,400,{error:'Thông tin trận không hợp lệ'});return}
    const raid=db.prepare('SELECT * FROM raids WHERE id=? AND user_id=?').get(id,user.id);
    if(!raid||raid.ended){json(res,409,{error:'Mã trận không hợp lệ hoặc đã sử dụng'});return}
    const wall=Math.max(0,now()-raid.started),tooFast=clientMs>wall*1.18+2500;
    db.prepare('UPDATE raids SET ended=?,reported_ms=?,anomaly=? WHERE id=?').run(now(),Math.round(clientMs),tooFast?1:0,id);
    if(tooFast){audit(user.id,'speed_anomaly',`reported ${clientMs} ms vs server ${wall} ms`);json(res,409,{error:'Phát hiện thời gian trong game chạy nhanh bất thường. Tiến độ trận không được xác nhận.',wallMs:wall});return}
    json(res,200,{ok:true,serverElapsedMs:wall,speedCheck:'passed',verifiedRewards:false});return;
  }
  json(res,404,{error:'Không có API này'});
 }catch(e){console.error('[SPLDB]',e.message);if(!res.headersSent)json(res,500,{error:'Lỗi server'});else res.end()}
});
server.listen(port,host,()=>{console.log(`[SPLDB] http://${host}:${port} | allowed origin ${allowedOrigin} | DB private ${dbPath}`);console.log('[SPLDB] LƯU Ý: save từ HTML là unverified, không dùng cho PvP/giao dịch có giá trị khi chưa có server-authoritative combat.');});
