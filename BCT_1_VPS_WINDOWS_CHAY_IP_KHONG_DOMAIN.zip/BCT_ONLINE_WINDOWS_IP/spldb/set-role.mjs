/** Grant or revoke the admin role on the ACCOUNT HOST only.
 * Stop SPLDB before running to avoid concurrent SQLite writers.
 * Usage: node spldb/set-role.mjs <account-username> admin|member --confirm
 * Existing accounts only; cannot be invoked by the game/browser.
 */
import {DatabaseSync} from 'node:sqlite';
import {resolve} from 'node:path';
import {existsSync} from 'node:fs';
const [username,role,flag]=process.argv.slice(2);
if(!username||!role||flag!=='--confirm'||!/^[a-z0-9_]{3,24}$/.test(username)||!['admin','member'].includes(role)){
 console.error('Usage: node spldb/set-role.mjs <username> admin|member --confirm');process.exit(1);
}
const file=resolve(process.env.SPLDB_DB_PATH||'./spldb/private/accounts.sqlite');
if(!existsSync(file)){console.error('Database not found: '+file);process.exit(1)}
const db=new DatabaseSync(file);
try{
 const cols=db.prepare('PRAGMA table_info(users)').all().map(x=>x.name);
 if(!cols.includes('role'))db.exec("ALTER TABLE users ADD COLUMN role TEXT NOT NULL DEFAULT 'member' CHECK(role IN ('member','admin'))");
 const row=db.prepare('SELECT id,username,role FROM users WHERE username=?').get(username);
 if(!row){console.error('Account not found. Register the account first.');process.exitCode=2}
 else{db.exec('BEGIN IMMEDIATE');try{db.prepare('UPDATE users SET role=? WHERE id=?').run(role,row.id);db.prepare('DELETE FROM sessions WHERE user_id=?').run(row.id);db.prepare('INSERT INTO audit(user_id,kind,detail,at) VALUES(?,?,?,?)').run(row.id,'role_change_cli',row.role+' -> '+role,Date.now());db.exec('COMMIT');console.log(`Role updated: ${row.username} -> ${role}. Sessions revoked; log in again.`)}catch(e){db.exec('ROLLBACK');throw e}}
}finally{db.close()}
