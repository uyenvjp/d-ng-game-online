#Requires -RunAsAdministrator
param([string]$PublicIP = '', [string]$InstallDir = 'C:\BCTOnline')
$ErrorActionPreference='Stop'
if (!$PublicIP) { $PublicIP=(Read-Host 'Nhap IP CONG KHAI cua VPS (KHONG them port RDP)').Trim() }
$ipObj=$null
if (-not [System.Net.IPAddress]::TryParse($PublicIP,[ref]$ipObj) -or
    $ipObj.AddressFamily -ne [System.Net.Sockets.AddressFamily]::InterNetwork -or
    $PublicIP -notmatch '^(25[0-5]|2[0-4]\d|1?\d?\d)\.(25[0-5]|2[0-4]\d|1?\d?\d)\.(25[0-5]|2[0-4]\d|1?\d?\d)\.(25[0-5]|2[0-4]\d|1?\d?\d)$') {
    throw 'IP khong hop le. Chi nhap IPv4, vi du: 1.2.3.4. KHONG nhap :PORT RDP.'
}
$parts=$PublicIP.Split('.') | ForEach-Object { [int]$_ }
if ($parts[0] -eq 0 -or $parts[0] -eq 10 -or $parts[0] -eq 127 -or
    $parts[0] -ge 224 -or ($parts[0] -eq 169 -and $parts[1] -eq 254) -or
    ($parts[0] -eq 172 -and $parts[1] -ge 16 -and $parts[1] -le 31) -or
    ($parts[0] -eq 192 -and $parts[1] -eq 168) -or
    ($parts[0] -eq 100 -and $parts[1] -ge 64 -and $parts[1] -le 127)) {
    throw 'IP nay khong phai IP Internet cong khai. Can IP public IPv4 cua VPS.'
}
# Free hostname resolves to this IP without DNS setup or domain purchase.
$hostname=($parts -join '-') + '.sslip.io'
Write-Host ''
Write-Host 'CHAY BANG 1 VPS WINDOWS - KHONG PHAI MUA TEN MIEN' -ForegroundColor Cyan
Write-Host "IP HTTP chi thu game  : http://$PublicIP (KHONG dang nhap)" -ForegroundColor Yellow
Write-Host "HTTPS de LOGIN + SAVE : https://$hostname" -ForegroundColor Green
Write-Host 'Dieu kien: Mo TCP 80 va 443, IP cong khai tro truc tiep VPS.'
Write-Host 'HTTPS co the that bai neu nha cung cap DNS/tai nguyen ACME bi gioi han.' -ForegroundColor Yellow
Write-Host ''
$src=Split-Path -Parent $MyInvocation.MyCommand.Path
& (Join-Path $src 'CAI_DAT_1_VPS.ps1') -Domain $hostname -InstallDir $InstallDir
if (!$?) { throw 'Trien khai that bai. Xem loi ben tren.' }
Write-Host ''
Write-Host "TEST GAME HTTP : http://$PublicIP" -ForegroundColor Yellow
Write-Host "ONLINE HTTPS  : https://$hostname" -ForegroundColor Green
Write-Host 'DUNG LINK HTTPS khi dang ky, dang nhap, luu du lieu.' -ForegroundColor Cyan
