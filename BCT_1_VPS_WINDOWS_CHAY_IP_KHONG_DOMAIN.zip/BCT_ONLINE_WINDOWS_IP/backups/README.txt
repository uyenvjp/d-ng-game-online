Thu muc runtime/du lieu tren VPS Windows. Khong dua database, secret hoac exe vao repository public.
