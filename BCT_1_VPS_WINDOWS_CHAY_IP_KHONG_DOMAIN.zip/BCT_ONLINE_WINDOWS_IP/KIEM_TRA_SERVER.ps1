﻿param([string]$InstallDir='C:\BCTOnline')
Write-Host 'Trang thai dich vu:'
Get-ScheduledTask -TaskName 'BCT_SPLDB','BCT_CADDY'|Select-Object TaskName,State
try{Invoke-RestMethod 'http://127.0.0.1:8787/health'|ConvertTo-Json -Compress}catch{Write-Warning "SPLDB khong tra loi: $_"}
Write-Host 'TCP 80/443/8787:'
Get-NetTCPConnection -LocalPort 80,443,8787 -State Listen -ErrorAction SilentlyContinue|Select-Object LocalAddress,LocalPort,OwningProcess
Write-Host 'Logs:'
Write-Host (Join-Path $InstallDir 'logs\spldb.log')
Write-Host (Join-Path $InstallDir 'logs\caddy.log')
