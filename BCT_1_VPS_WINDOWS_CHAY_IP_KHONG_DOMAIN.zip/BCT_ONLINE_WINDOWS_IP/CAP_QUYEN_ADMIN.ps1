﻿#Requires -RunAsAdministrator
param([string]$Username='', [ValidateSet('admin','member')][string]$Role='admin', [string]$InstallDir='C:\BCTOnline')
$ErrorActionPreference='Stop'
if(!$Username){$Username=Read-Host 'Nhap username da dang ky'}
if($Username -notmatch '^[a-z0-9_]{3,24}$'){throw 'Username khong hop le'}
$base=[System.IO.Path]::GetFullPath($InstallDir)
$cfg=Get-Content (Join-Path $base 'config\install.json') -Raw|ConvertFrom-Json
$env:SPLDB_DB_PATH=Join-Path $base 'data\accounts.sqlite'
# Stop the writer before SQLite role migration, then revoke sessions.
Stop-ScheduledTask -TaskName 'BCT_SPLDB' -ErrorAction SilentlyContinue
Start-Sleep -Seconds 2
try{& $cfg.NodeExe (Join-Path $base 'spldb\set-role.mjs') $Username $Role '--confirm';if($LASTEXITCODE -ne 0){throw 'Cap quyen that bai'}}
finally{Start-ScheduledTask -TaskName 'BCT_SPLDB'}
Write-Host 'Dang xuat roi dang nhap lai game de cap nhat quyen.'
