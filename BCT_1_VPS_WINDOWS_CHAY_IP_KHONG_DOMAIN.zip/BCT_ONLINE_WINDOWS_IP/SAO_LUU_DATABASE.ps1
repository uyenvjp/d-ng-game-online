﻿#Requires -RunAsAdministrator
param([string]$InstallDir='C:\BCTOnline')
$ErrorActionPreference='Stop'
$base=[System.IO.Path]::GetFullPath($InstallDir)
$cfg=Get-Content (Join-Path $base 'config\install.json') -Raw|ConvertFrom-Json
$env:SPLDB_DB_PATH=Join-Path $base 'data\accounts.sqlite'
& $cfg.NodeExe (Join-Path $base 'spldb\backup.mjs') (Join-Path $base 'backups')
if($LASTEXITCODE -ne 0){throw 'Backup that bai'}
Write-Host 'Backup xong. Nho copy ra may khac/cloud an toan va kiem tra restore.'
