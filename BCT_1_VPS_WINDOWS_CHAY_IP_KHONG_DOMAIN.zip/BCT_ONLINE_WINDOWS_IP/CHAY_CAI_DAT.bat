@echo off
cd /d "%~dp0"
echo Run this file as Administrator on Windows VPS.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CAI_DAT_1_VPS.ps1"
pause
