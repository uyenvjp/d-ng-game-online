@echo off
cd /d "%~dp0"
echo Cai dat BCT online 1 VPS Windows KHONG CAN MUA DOMAIN.
echo Chi nhap IP cong khai, KHONG nhap :port RDP.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0CAI_DAT_BANG_IP.ps1"
pause
