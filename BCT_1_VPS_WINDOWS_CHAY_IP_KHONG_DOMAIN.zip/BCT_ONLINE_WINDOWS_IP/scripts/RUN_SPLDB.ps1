﻿# Run under Windows Task Scheduler (LOCALSERVICE), not from a browser.
$ErrorActionPreference = 'Stop'
$base = Split-Path $PSScriptRoot -Parent
$config = Get-Content (Join-Path $base 'config\install.json') -Raw | ConvertFrom-Json
$env:NODE_ENV = 'production'
$env:SPLDB_HOST = '127.0.0.1'
$env:SPLDB_PORT = '8787'
$env:SPLDB_ORIGIN = 'https://' + $config.Domain
$env:SPLDB_COOKIE_SECURE = '1'
$env:SPLDB_DB_PATH = Join-Path $base 'data\accounts.sqlite'
$env:SPLDB_SAVE_MAX_BYTES = '524288'
$env:SPLDB_HMAC_KEY_FILE = Join-Path $base 'config\spldb-hmac-secret.txt'
$node = $config.NodeExe
Set-Location $base
& $node (Join-Path $base 'spldb\server.mjs') *>> (Join-Path $base 'logs\spldb.log')
