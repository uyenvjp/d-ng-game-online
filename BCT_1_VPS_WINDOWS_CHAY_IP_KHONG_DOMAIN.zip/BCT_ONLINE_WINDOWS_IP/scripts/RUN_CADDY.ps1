﻿# Run Caddy as Windows Scheduled Task (LOCALSERVICE).
$ErrorActionPreference = 'Stop'
$base = Split-Path $PSScriptRoot -Parent
$exe = Join-Path $base 'bin\caddy.exe'
Set-Location $base
& $exe run --config (Join-Path $base 'config\Caddyfile') --adapter caddyfile *>> (Join-Path $base 'logs\caddy.log')
